const table = document.querySelector('table');

table.addEventListener('click', function(event) {
  const target = event.target;
  if (target.tagName === 'TD') {
    const row = target.parentElement;
    const id = row.dataset.id;
    const email = row.dataset.email;
    const phone = row.dataset.phone;
    const hireDate = row.dataset.hiredate;
    const skills = row.dataset.skills;
    const name = row.cells[1].textContent;

    // Check if a details row already exists for this row
    const existingDetailsRow = row.nextElementSibling;
    if (existingDetailsRow && existingDetailsRow.classList.contains('details-row')) {
      existingDetailsRow.remove(); // Remove it if it exists
      return; // Exit the function
    }

    // Create the details row
    const detailsRow = document.createElement('tr');
    detailsRow.classList.add('details-row');
    detailsRow.innerHTML = `
      <td colspan="4">
        <strong>${name} - Details</strong><br>
        Email: ${email}<br>
        Phone: ${phone}<br>
        Hire Date: ${hireDate}<br>
        Skills: ${skills}
      </td>
    `;
    row.insertAdjacentElement('afterend', detailsRow); // Insert after the clicked row
  }
});